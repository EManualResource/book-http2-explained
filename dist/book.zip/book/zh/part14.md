# 14. 致谢

介绍数据包格式的乐高图片来自于Mark Nottingham，感谢他给我提供的灵感。

HTTP趋势数据来自http://httparchive.org。

RTT图来自Mike Belshe的演讲。

感谢我的孩子Agnes和Rex，他们把乐高玩具借给我作为head of line的图片。

感谢以下为我提供校对和反馈的朋友：Kjell Ericson, Bjorn Reese, Linux Swälas和Anthony Bryan。是你们让这份文档变得更好！

在完成文档的过程中，以下朋友反馈了bug帮助改进文档：Mikael Olsson, Remi Gacogne, Benjamin Kircher, saivlis, florin-andrei-tp, Brett Anthoine, Nick Parlante, Matthew King, Nicolas Peels, Jon Forrest, sbrickey, Marcin Olak, Gary Rowe, Ben Frain, Mats Linander, Raul Siles, Alex Lee, Richard Moore